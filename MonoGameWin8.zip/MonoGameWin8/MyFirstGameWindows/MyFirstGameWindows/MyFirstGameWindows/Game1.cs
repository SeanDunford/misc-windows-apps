using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;

namespace MyFirstGameWindows
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager _graphics;
        SpriteBatch _spriteBatch;
        Texture2D player;
        int playerCurrentFrame = 0;
        double playerAnimationDelay = .05;
        double currentPlayerAnimationDelay = 0;
        Texture2D platform;
        float platformOffset = 0;
        float platformScrollSpeed = 200;
        Texture2D playerJump;
        bool isPressed = false;
        bool jumping = false;
        float velocityY = 0;
        float offsetY = 0;
        float accelerationY = 600f;
        float startVelocityY = -500f;
        SoundEffect playerJumpSound;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            player = Content.Load<Texture2D>("run");
            platform = Content.Load<Texture2D>("platform");
            playerJump = Content.Load<Texture2D>("jump");
            playerJumpSound = Content.Load<SoundEffect>("playerJump");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // TODO: Add your update logic here
            if (jumping)
            {
                offsetY += velocityY * (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (offsetY > 0)
                {
                    offsetY = 0;
                    jumping = false;
                }
                velocityY += accelerationY * (float)gameTime.ElapsedGameTime.TotalSeconds;
            }

            isPressed = Mouse.GetState().LeftButton == ButtonState.Pressed;

            if (isPressed && !jumping)
            {
                jumping = true;
                currentPlayerAnimationDelay = 0;
                velocityY = startVelocityY;
                playerJumpSound.Play();
            }

            currentPlayerAnimationDelay += gameTime.ElapsedGameTime.TotalSeconds;
            if (!jumping)
            {
                while (currentPlayerAnimationDelay > playerAnimationDelay)
                {
                    playerCurrentFrame++;
                    playerCurrentFrame = playerCurrentFrame % 10;
                    currentPlayerAnimationDelay -= playerAnimationDelay;
                }
            }
            else
            {
                double totalJumpTime = Math.Abs(startVelocityY * 2) / accelerationY;
                playerCurrentFrame = (int)MathHelper.Lerp(0, 10.999f, (float)(currentPlayerAnimationDelay / totalJumpTime));
                if (playerCurrentFrame > 10) playerCurrentFrame = 10;
            }
            platformOffset += platformScrollSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (platformOffset > platform.Width) platformOffset -= platform.Width;



            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            if (!jumping)
            {
                _spriteBatch.Draw(player, new Vector2(80, 300 + offsetY), new Rectangle(playerCurrentFrame * player.Height, 0, player.Height, player.Height),
                    Color.White, 0, Vector2.Zero, 1, SpriteEffects.FlipHorizontally, 0);
            }
            else
            {
                _spriteBatch.Draw(playerJump, new Vector2(80, 300 + offsetY), new Rectangle(playerCurrentFrame * playerJump.Height, 0, playerJump.Height, playerJump.Height),
                    Color.White, 0, Vector2.Zero, 1, SpriteEffects.FlipHorizontally, 0);
            }

            float deviceWidth = GraphicsDevice.PresentationParameters.BackBufferWidth;
            for (float f = -platformOffset; f < deviceWidth; f += platform.Width)
            {
                _spriteBatch.Draw(platform, new Vector2(f, 300 + player.Height),
                    Color.White);
            }
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
