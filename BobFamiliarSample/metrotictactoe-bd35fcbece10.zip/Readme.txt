Metro Tic-Tac-Toe

Author: Bob Familiar
Git: http://github.com/bobfamiliar
Twitter: http://twitter.com/bobfmailiar
Blog: http://blogs.msdn.com/bobfmailiar
Web: http://about.me/bobfamiliar

Summary:

Tic-Tac-Toe is a Windows 8 Metro Style Game developed using MonoGame for Windows 8. The intent of this code The intent of this code is to help XNA developers with porting their XNA apps to Windows 8. The code for the game is intended for demo purposes only and should be considered a starting kit for future apps you may write.  

DISCLAIMER: 

The sample code described herein is provided on an "as is" basis, without warranty of any kind, to the fullest extent permitted by law. Both Microsoft and I do not warrant or guarantee the individual success developers may have in implementing the sample code on their development platforms or in using their own Web server configurations. 

Microsoft and I do not warrant, guarantee or make any representations regarding the use, results of use, accuracy, timeliness or completeness of any data or information relating to the sample code. Microsoft and I disclaim all warranties, express or implied, and in particular, disclaims all warranties of merchantability, fitness for a particular purpose, and warranties related to the code, or any service or software related thereto. 

Microsoft and I shall not be liable for any direct, indirect or consequential damages or costs of any type arising out of any action taken by you or others related to the sample code.